function buttonHover(){
    document.getElementById("paraId").innerText = new Date().toString();
}

function buttonOut(){
    document.getElementById("paraId").innerText = "Hover on the button to see date";
}